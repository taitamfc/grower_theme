        </div><!-- #themesflat-content -->
    </div><!-- #main-content -->
    <?php do_action( 'tf_footer' ); ?>
    <?php wp_footer(); ?>
    </div><!-- /.themesflat-boxed -->
</body>
</html> 