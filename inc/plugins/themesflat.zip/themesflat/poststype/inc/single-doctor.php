<?php
get_header(); 
?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="wrap-content-area">
				<div id="primary" class="content-area">	
					<main id="main" class="main-content" role="main">
						<div class="entry-content">	
							<?php while ( have_posts() ) : the_post(); ?>
								<div class="row">
									<div class="col-lg-4 col-md-12">
										<div class="featured-post">
											<?php the_post_thumbnail('themesflat-doctor-image'); ?>
											<div class="meta-doctor">
												<?php 
													$social_html = $social_1 = $social_2 = $social_3 = $social_4 = '';
													$target_1 = $target_2 = $target_3 = $target_4 = '';
													$nofollow_1 = $nofollow_2 = $nofollow_3 = $nofollow_4 = '';
													$icon_1 = $icon_2 = $icon_3 = $icon_4 = '';
													$link_1 = $link_2 = $link_3 = $link_4 = '';

													$icon_1 = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( themesflat_get_opt_elementor('doctor_post_social_icon_1') );
													$icon_2 = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( themesflat_get_opt_elementor('doctor_post_social_icon_2') );
													$icon_3 = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( themesflat_get_opt_elementor('doctor_post_social_icon_3') );
													$icon_4 = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( themesflat_get_opt_elementor('doctor_post_social_icon_4') );

													if ( $icon_1 != '' ) {
														if ( ! empty( themesflat_get_opt_elementor('doctor_post_social_link_1')['url'] ) ) {
															$link_1 = themesflat_get_opt_elementor('doctor_post_social_link_1')['url'];
															$target_1 = themesflat_get_opt_elementor('doctor_post_social_link_1')['is_external'] ? ' target="_blank"' : '';
															$nofollow_1 = themesflat_get_opt_elementor('doctor_post_social_link_1')['nofollow'] ? ' rel="nofollow"' : '';
														}												

														$social_1 .= '<a href="' . $link_1 . '" ' . $target_1 . $nofollow_1 . '>'.$icon_1.'</a>';
													}

													if ( $icon_2 != '' ) {
														if ( ! empty( themesflat_get_opt_elementor('doctor_post_social_link_2')['url'] ) ) {
															$link_2 = themesflat_get_opt_elementor('doctor_post_social_link_2')['url'];
															$target_2 = themesflat_get_opt_elementor('doctor_post_social_link_2')['is_external'] ? ' target="_blank"' : '';
															$nofollow_2 = themesflat_get_opt_elementor('doctor_post_social_link_2')['nofollow'] ? ' rel="nofollow"' : '';
														}												

														$social_2 .= '<a href="' . $link_2 . '" ' . $target_2 . $nofollow_2 . '>'.$icon_2.'</a>';
													}

													if ( $icon_3 != '' ) {
														if ( ! empty( themesflat_get_opt_elementor('doctor_post_social_link_3')['url'] ) ) {
															$link_3 = themesflat_get_opt_elementor('doctor_post_social_link_3')['url'];
															$target_3 = themesflat_get_opt_elementor('doctor_post_social_link_3')['is_external'] ? ' target="_blank"' : '';
															$nofollow_3 = themesflat_get_opt_elementor('doctor_post_social_link_3')['nofollow'] ? ' rel="nofollow"' : '';
														}												

														$social_3 .= '<a href="' . $link_3 . '" ' . $target_3 . $nofollow_3 . '>'.$icon_3.'</a>';
													}

													if ( $icon_4 != '' ) {
														if ( ! empty( themesflat_get_opt_elementor('doctor_post_social_link_4')['url'] ) ) {
															$link_4 = themesflat_get_opt_elementor('doctor_post_social_link_4')['url'];
															$target_4 = themesflat_get_opt_elementor('doctor_post_social_link_4')['is_external'] ? ' target="_blank"' : '';
															$nofollow_4 = themesflat_get_opt_elementor('doctor_post_social_link_4')['nofollow'] ? ' rel="nofollow"' : '';
														}												

														$social_4 .= '<a href="' . $link_4 . '" ' . $target_4 . $nofollow_4 . '>'.$icon_4.'</a>';
													}

													if ( $icon_1 != '' || $icon_2 != '' || $icon_3 != '' || $icon_4 != '' ){
														echo '<div class="social">'.$social_1.$social_2.$social_3.$social_4.'</div>';
													}
												?>

												<?php if (themesflat_get_opt_elementor('doctor_post_phone') != ''): ?>
													<div class="phone list-info">
														<?php 
					                                        $doctor_post_icon_phone  = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( themesflat_get_opt_elementor('doctor_post_icon_phone'), [ 'aria-hidden' => 'true' ] );
					                                        if ($doctor_post_icon_phone) {
					                                            echo '<span class="post-icon">'.$doctor_post_icon_phone.'</span>';
					                                        }
				                                        ?>
				                                        <span><?php echo themesflat_get_opt_elementor('doctor_post_phone'); ?></span>
													</div>
												<?php endif; ?>												

												<?php if (themesflat_get_opt_elementor('doctor_post_mail') != ''): ?>
													<div class="mail list-info">
														<?php 
					                                        $doctor_post_icon_mail  = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( themesflat_get_opt_elementor('doctor_post_icon_mail'), [ 'aria-hidden' => 'true' ] );
					                                        if ($doctor_post_icon_mail) {
					                                            echo '<span class="post-icon">'.$doctor_post_icon_mail.'</span>';
					                                        }
				                                        ?>
				                                        <span><?php echo themesflat_get_opt_elementor('doctor_post_mail'); ?></span>
													</div>
												<?php endif; ?>

												<?php if (themesflat_get_opt_elementor('doctor_post_button') != ''):
													$btn_link = $btn_target = $btn_nofollow = '';
													if ( ! empty( themesflat_get_opt_elementor('doctor_post_button_link')['url'] ) ) {
														$btn_link = 'href='.themesflat_get_opt_elementor('doctor_post_button_link')['url'].'';
														$btn_target = themesflat_get_opt_elementor('doctor_post_button_link')['is_external'] ? ' target="_blank"' : '';
														$btn_nofollow = themesflat_get_opt_elementor('doctor_post_button_link')['nofollow'] ? ' rel="nofollow"' : '';
													}
													?>															
		                                        	<a class="themesflat-button" <?php echo esc_attr($btn_link); ?> <?php echo esc_attr($btn_target); ?> <?php echo esc_attr($btn_nofollow); ?>><?php echo themesflat_get_opt_elementor('doctor_post_button'); ?></a>
												<?php endif; ?>
											</div>
										</div>										
									</div>
									<div class="col-lg-8 col-md-12">

										<?php if ( themesflat_get_opt('doctor_featured_title') != '' ): ?>
										<h1 class="post-title"><?php the_title(); ?></h1>
										<?php endif; ?>
										
										<?php the_content(); ?>
									</div>
								</div>
							<?php endwhile; // end of the loop. ?>
						</div><!-- ./entry-content -->
					</main><!-- #main -->
				</div><!-- #primary -->
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>