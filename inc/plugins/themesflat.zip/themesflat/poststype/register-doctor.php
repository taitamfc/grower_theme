<?php
add_action('init', 'themesflat_register_doctor_post_type');
/**
  * Register Doctor post type
*/
function themesflat_register_doctor_post_type() {
    $doctor_slug = 'doctor';
    $labels = array(
        'name'                  => esc_html__( 'Doctor', 'themesflat' ),
        'singular_name'         => esc_html__( 'Doctor', 'themesflat' ),
        'menu_name'             => esc_html__( 'Doctor', 'themesflat' ),
        'add_new'               => esc_html__( 'New Doctor', 'themesflat' ),
        'add_new_item'          => esc_html__( 'Add New Doctor', 'themesflat' ),
        'new_item'              => esc_html__( 'New Doctor Item', 'themesflat' ),
        'edit_item'             => esc_html__( 'Edit Doctor Item', 'themesflat' ),
        'view_item'             => esc_html__( 'View Doctor', 'themesflat' ),
        'all_items'             => esc_html__( 'All Doctor', 'themesflat' ),
        'search_items'          => esc_html__( 'Search Doctor', 'themesflat' ),
        'not_found'             => esc_html__( 'No Doctor Items Found', 'themesflat' ),
        'not_found_in_trash'    => esc_html__( 'No Doctor Items Found In Trash', 'themesflat' ),
        'parent_item_colon'     => esc_html__( 'Parent Doctor:', 'themesflat' ),
        'not_found'             => esc_html__( 'No Doctor found', 'themesflat' ),
        'not_found_in_trash'    => esc_html__( 'No Doctor found in Trash', 'themesflat' )

    );
    $args = array(
        'labels'      => $labels,
        'supports'    => array( 'title', 'editor', 'thumbnail', 'custom-fields', 'elementor'  ),
        'rewrite'       => array( 'slug' => $doctor_slug ),
        'public'      => true,   
        'show_in_rest' => true,  
        'has_archive' => true 
    );
    register_post_type( 'doctor', $args );
    flush_rewrite_rules();
}

add_filter( 'post_updated_messages', 'themesflat_doctor_updated_messages' );
/**
  * Doctor update messages.
*/
function themesflat_doctor_updated_messages ( $messages ) {
    Global $post, $post_ID;
    $messages[esc_html__( 'doctor' )] = array(
        0  => '',
        1  => sprintf( esc_html__( 'Doctor Updated. <a href="%s">View Doctor</a>', 'themesflat' ), esc_url( get_permalink( $post_ID ) ) ),
        2  => esc_html__( 'Custom Field Updated.', 'themesflat' ),
        3  => esc_html__( 'Custom Field Deleted.', 'themesflat' ),
        4  => esc_html__( 'Doctor Updated.', 'themesflat' ),
        5  => isset( $_GET['revision']) ? sprintf( esc_html__( 'Doctor Restored To Revision From %s', 'themesflat' ), wp_post_revision_title((int)$_GET['revision'], false)) : false,
        6  => sprintf( esc_html__( 'Doctor Published. <a href="%s">View Doctor</a>', 'themesflat' ), esc_url( get_permalink( $post_ID ) ) ),
        7  => esc_html__( 'Doctor Saved.', 'themesflat' ),
        8  => sprintf( esc_html__('Doctor Submitted. <a target="_blank" href="%s">Preview Doctor</a>', 'themesflat' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
        9  => sprintf( esc_html__( 'Doctor Scheduled For: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Doctor</a>', 'themesflat' ),date_i18n( esc_html__( 'M j, Y @ G:i', 'themesflat' ), strtotime( $post->post_date ) ), esc_url( get_permalink( $post_ID ) ) ),
        10 => sprintf( esc_html__( 'Doctor Draft Updated. <a target="_blank" href="%s">Preview Doctor</a>', 'themesflat' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
    );
    return $messages;
}

add_action( 'init', 'themesflat_register_doctor_taxonomy' );
/**
  * Register project taxonomy
*/
function themesflat_register_doctor_taxonomy() {
    /*Doctor Categories*/    
    $doctor_cat_slug = 'doctor_category'; 
    $labels = array(
        'name'                       => esc_html__( 'Doctor Categories', 'themesflat' ),
        'singular_name'              => esc_html__( 'Categories', 'themesflat' ),
        'search_items'               => esc_html__( 'Search Categories', 'themesflat' ),
        'menu_name'                  => esc_html__( 'Categories', 'themesflat' ),
        'all_items'                  => esc_html__( 'All Categories', 'themesflat' ),
        'parent_item'                => esc_html__( 'Parent Categories', 'themesflat' ),
        'parent_item_colon'          => esc_html__( 'Parent Categories:', 'themesflat' ),
        'new_item_name'              => esc_html__( 'New Categories Name', 'themesflat' ),
        'add_new_item'               => esc_html__( 'Add New Categories', 'themesflat' ),
        'edit_item'                  => esc_html__( 'Edit Categories', 'themesflat' ),
        'update_item'                => esc_html__( 'Update Categories', 'themesflat' ),
        'add_or_remove_items'        => esc_html__( 'Add or remove Categories', 'themesflat' ),
        'choose_from_most_used'      => esc_html__( 'Choose from the most used Categories', 'themesflat' ),
        'not_found'                  => esc_html__( 'No Categories found.' ),
        'menu_name'                  => esc_html__( 'Categories' ),
    );
    $args = array(
        'labels'        => $labels,
        'rewrite'       => array('slug'=>$doctor_cat_slug),
        'hierarchical'  => true,
        'show_in_rest'  => true,
    );
    register_taxonomy( 'doctor_category', 'doctor', $args );
    flush_rewrite_rules();
}

