<?php foreach ($settings['carousel_list'] as $carousel): ?>
    <?php 
    $icon_quote = '';
    $icon_quote = \Elementor\Addon_Elementor_Icon_manager_carenow::render_icon( $carousel['icon_quote'], [ 'aria-hidden' => 'true' ] ); 
    ?>
    <div class="item">  
        <div class="item-testimonial">
			<div class="wrap-avatar">
				<div class="avatar"><img src="<?php echo esc_attr($carousel['avatar']['url']); ?>" alt="image"></div>
				<?php if ($icon_quote): ?>
					<div class="icon-quote"><?php echo sprintf($icon_quote); ?></div>
					<div class="bg-icon-quote"><?php echo sprintf($icon_quote); ?></div>
				<?php endif; ?>
			</div>
			<div class="description"><?php echo sprintf( '%1$s', $carousel['description'] ); ?></div>
			<div class="name"><?php echo esc_attr($carousel['name']); ?></div>
			<div class="position"><?php echo esc_attr($carousel['position']); ?></div>			
		</div>
    </div>              
<?php endforeach;?>

