<?php
/**
 * The template for displaying archive gallery.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package carenow
 */

get_header(); ?>
<?php 
$gallery_number_post = themesflat_get_opt( 'gallery_number_post' ) ? themesflat_get_opt( 'gallery_number_post' ) : 6;
$columns = themesflat_get_opt('gallery_grid_columns');
$themesflat_paging_style = themesflat_get_opt('gallery_archive_pagination_style');
$orderby = themesflat_get_opt('gallery_order_by');
$order = themesflat_get_opt('gallery_order_direction');
$exclude = themesflat_get_opt('gallery_exclude');
$show_filter = themesflat_get_opt('gallery_show_filter');
$filter_category_order = themesflat_get_opt('gallery_filter_category_order');	
$terms_slug = wp_list_pluck( get_terms( 'gallery_category','hide_empty=0'), 'slug' );
$filters =      wp_list_pluck( get_terms( 'gallery_category','hide_empty=0'), 'name','slug' );
$show_filter_class = '';

$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

$query_args = array(
    'post_type' => 'gallery',
    'orderby'   => $orderby,
    'order' => $order,    
    'paged' => $paged,    
    'posts_per_page' => $gallery_number_post,  
    'tax_query' => array(
        array(
            'taxonomy' => 'gallery_category',   
            'field'    => 'slug',                   
        	'terms'    => $terms_slug,
        ),
    ),
);	

if ( ! empty( $exclude ) ) {				
	if ( ! is_array( $exclude ) )
		$exclude = explode( ',', $exclude );

	$query_args['post__not_in'] = $exclude;
}
$query = new WP_Query( $query_args );
?>

<div class="themesflat-gallery-taxonomy">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wrap-content-area">
                    <div id="primary" class="content-area"> 
                        <main id="main" class="main-content" role="main"> 
                            <?php
                                //Build the filter navigation
                                if ( $show_filter == 1 ) {  
                                    $show_filter_class = 'show-filter';         
                                    echo '<ul class="gallery-filter posttype-filter"><li class="active"><a data-filter="*" href="#">' . esc_html__( 'All', 'themesflat' ) . '</a></li>'; 
                                        if ($filter_category_order == '') { 

                                            foreach ($filters as $key => $value) {
                                                echo '<li><a data-filter=".' . esc_attr( strtolower($key)) . '" href="#" title="' . esc_attr( $value ) . '">' . esc_html( $value ) . '</a></li>'; 
                                            }
                                        
                                        }
                                        else {
                                            $filter_category_order = explode(",", $filter_category_order);
                                            foreach ($filter_category_order as $key) {
                                                $key = trim($key);
                                                echo '<li><a data-filter=".' . esc_attr( strtolower($key)) . '" href="#" title="' . esc_attr( $filters[$key] ) . '">' . esc_html( $filters[$key] ) . '</a></li>'; 
                                            }
                                        }
                                    echo '</ul>';
                                }  
                            ?>
                            <div class="container-filter wrap-gallery-post row column-<?php echo esc_attr($columns); ?> <?php echo esc_attr($show_filter_class); ?>">
                                <?php 
                                
                                if( $query->have_posts() ) {
                                    while ( $query->have_posts() ) : $query->the_post();                	
                        		        $id = $post->ID;
                        		        $termsArray = get_the_terms( $id, 'gallery_category' );
                        		        $termsString = "";

                        		        if ( $termsArray ) {
                        		        	foreach ( $termsArray as $term ) {
                        		        		$itemname = strtolower( $term->slug ); 
                        		        		$itemname = str_replace( ' ', '-', $itemname );
                        		        		$termsString .= $itemname.' ';
                        		        	}
                        		        }
                                    	?>           
                                        <div class="item <?php echo esc_attr( $termsString ); ?>">
                                            <div class="gallery-post gallery-post-<?php the_ID(); ?>">
                                                <div class="featured-post">
                                                    <a href="<?php echo get_the_permalink(); ?>">
                                                    <?php 
                                                        if ( has_post_thumbnail() ) { 
                                                            $themesflat_thumbnail = "themesflat-service-image";                              
                                                            the_post_thumbnail( $themesflat_thumbnail );
                                                        }                                           
                                                    ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h2 class="title"><?php echo get_the_title(); ?></h2>
                                                    <div class="post-meta">
                                                        <?php echo the_terms( get_the_ID(), 'gallery_category', '', ' , ', '' ); ?>
                                                    </div>                                                    
                                                </div>
                                            </div>
                                        </div>                    
                                        <?php 
                                    endwhile;
                                } else {
                                    get_template_part( 'template-parts/content', 'none' );
                                }
                                ?>            
                            </div>
                            <?php 
                                themesflat_pagination_posttype($query);
                                wp_reset_postdata();
                            ?>  
                        </main><!-- #main -->
                    </div><!-- #primary -->
                    <?php 
                    if ( themesflat_get_opt( 'gallery_layout' ) == 'sidebar-left' || themesflat_get_opt( 'gallery_layout' ) == 'sidebar-right' ) :
                        get_sidebar();
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </div>
</div><!-- /.themesflat-gallery-taxonomy -->

<?php get_footer(); ?>