<?php
get_header();
$term_slug = $wp_query->tax_query->queries[0]['terms'][0];
$gallery_number_post = themesflat_get_opt( 'gallery_number_post' ) ? themesflat_get_opt( 'gallery_number_post' ) : 6;
$columns = themesflat_get_opt('gallery_grid_columns');
$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
$themesflat_paging_style = themesflat_get_opt('gallery_archive_pagination_style');
    
$args = array(
    'post_type' => 'gallery',
    'paged'     => $paged,
    'posts_per_page' => $gallery_number_post,
);
$args['tax_query'] = array(
    array(
        'taxonomy' => 'gallery_category',
        'field'    => 'slug',
        'terms'    => $term_slug
    ),
); 
$query = new WP_Query($args);
?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="wrap-content-area">
                <div id="primary" class="content-area"> 
                    <main id="main" class="main-content" role="main">                            
                        <div class="themesflat-gallery-taxonomy">                            
                            <div class="wrap-gallery-post row column-<?php echo esc_attr($columns); ?>">
                                <?php                                 
                                if( $query->have_posts() ) {
                                    while ( $query->have_posts() ) : $query->the_post(); ?>           
                                        <div class="item">
                                            <div class="gallery-post gallery-post-<?php the_ID(); ?>">
                                                <div class="featured-post">
                                                    <a href="<?php echo get_the_permalink(); ?>">
                                                    <?php 
                                                        if ( has_post_thumbnail() ) { 
                                                            $themesflat_thumbnail = "themesflat-service-image";                              
                                                            the_post_thumbnail( $themesflat_thumbnail );
                                                        }                                           
                                                    ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h2 class="title"><?php echo get_the_title(); ?></h2>
                                                    <div class="post-meta">
                                                        <?php echo the_terms( get_the_ID(), 'gallery_category', '', ' , ', '' ); ?>
                                                    </div>                                                    
                                                </div>
                                            </div>
                                        </div>                    
                                        <?php 
                                    endwhile; 
                                }
                                ?>            
                            </div>
                        </div><!-- /.themesflat-gallery-taxonomy -->
                        <?php 
                            themesflat_pagination_posttype($query);
                            wp_reset_postdata();
                        ?> 
                    </main><!-- #main -->
                </div><!-- #primary -->
                <?php 
                if ( themesflat_get_opt( 'gallery_layout' ) == 'sidebar-left' || themesflat_get_opt( 'gallery_layout' ) == 'sidebar-right' ) :
                    get_sidebar();
                endif;
                ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>