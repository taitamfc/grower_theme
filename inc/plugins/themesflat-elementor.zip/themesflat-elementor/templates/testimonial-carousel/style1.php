<?php foreach ($settings['carousel_list'] as $carousel): ?>
    <div class="item">
        <div class="item-testimonial">
            <div class="wrap-author"> 
                <?php if ($carousel['avatar']['url']): ?>               
                    <div class="avatar"><img src="<?php echo esc_attr($carousel['avatar']['url']); ?>" alt="image"></div>
                <?php endif; ?>
                <div class="content">
                    <?php if ($carousel['name']): ?> 
                        <div class="name"><?php echo esc_attr($carousel['name']); ?></div>
                    <?php endif; ?>

                    <?php if ($carousel['position']): ?> 
                        <div class="position"><?php echo esc_attr($carousel['position']); ?></div>
                    <?php endif; ?>
                </div>
                <?php if (\Elementor\Addon_Elementor_Icon_manager_carenow::render_icon($carousel['icon_quote'],['aria-hidden'=>'true'])): ?>
                    <div class="icon-quote"><?php echo sprintf(\Elementor\Addon_Elementor_Icon_manager_carenow::render_icon($carousel['icon_quote'],['aria-hidden'=>'true'])); ?></div>
                <?php endif; ?>
            </div>
            <?php if ($carousel['description']): ?> 
                <div class="description"><?php echo sprintf( '%1$s', $carousel['description'] ); ?></div>
            <?php endif; ?>
        </div>
    </div>              
<?php endforeach;?>

